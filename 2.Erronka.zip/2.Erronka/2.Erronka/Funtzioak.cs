﻿using ClosedXML.Excel;
using MySql.Data.MySqlClient;
using Mysqlx;
using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Erronka
{
    public class Funtzioak
    {
        static private List<Tiketa> lt = new List<Tiketa>();
        static string autosalmentaIzena = "";
        public static void Ekintzak()
        {
            string connStr = "Server=localhost;Port=3306;Database=supermerkatua;Uid=root;Pwd=root;";
            Datubasea.BaskulakKargatu(connStr);
            Datubasea.ProduktuakKargatu(connStr);
            Datubasea.AutoSalmentaKargatu(connStr);
            bool luzera = TiketakIrakurri();
                if (!luzera)
                {
                    Console.WriteLine("Ticketen bateko saltzailea aldatu nahi duzu?");
                    Console.WriteLine("Aldatzeko Bai sartu, bestela beste edozer sartu");
                    string erantzuna = (Console.ReadLine() ?? "").ToLower();
                    if (erantzuna == "bai")
                    {
                        Saltzailea.SaltzaileaAldatu(lt);
                    }
                    XML.TiketakXmlraGorde(lt);
                    string ruta = XML.HartuXmlBidea();
                    bool ok = XML.Balidatu(ruta, @"\\MSIDEANDONI\CentralTicketBAI\XML\Tiketak.xsd");
                    Spectre.Console.AnsiConsole.MarkupLine(ok? "[green]✓[/] [bold]XML balidatua izan da[/]" : "[red]✗[/] [bold]XML ezin izan da balidatu[/]");
                    XML.BidaliXml();
                    XML.MugituXml();
                    Datubasea.TiketakMysqleraSartu(connStr, lt);
                    Console.WriteLine();
                    EnterItxaron();
                }
                else
                {
                    Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold]Ez dago tiketik prozesatzeko[/]");
                    Console.WriteLine();
                    EnterItxaron();
                }
        }
        public static void MugituTxtGuztiak(string iturriaKarpeta)
        {
            string helmugaKarpeta = @"\\MSIDEANDONI\CentralTicketBAI\BackUp\TICKET";

            Directory.CreateDirectory(helmugaKarpeta);

            foreach (string fitxategia in Directory.GetFiles(iturriaKarpeta, "*.txt"))
            {
                string izena = Path.GetFileName(fitxategia);
                string helmugaBidea = Path.Combine(helmugaKarpeta, izena);

                File.Move(fitxategia, helmugaBidea, true);
            }
        }
        public static bool TiketakIrakurri()
        {
            lt.Clear();

            string lekua = @"\\MSIDEANDONI\CentralTicketBAI";
            string[] baskulak = { "frutategia", "harategia", "okindegia", "txarkutegia" };
            CultureInfo es = new CultureInfo("es-ES");

            foreach (string baskula in baskulak)
            {
                string karpetatiketak = Path.Combine(lekua, baskula, "Tiketak");

                if (!Directory.Exists(karpetatiketak))
                {
                    Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold]Ez da existitzen[/]"+ karpetatiketak);
                    continue;
                }

                foreach (string fitx in Directory.GetFiles(karpetatiketak, "*.txt"))
                {
                    DateTime data = LortuFitxategiData(fitx);

                    using (StreamReader sr = File.OpenText(fitx))
                    {
                        string lerroa = sr.ReadLine();

                        if (lerroa == null)
                            continue;

                        var parts = lerroa.Split('$');

                        if (parts.Length == 5)
                        {
                            string baskKey = baskula.Trim().ToLowerInvariant();

                            if (!Datubasea.baskulaIdByName.TryGetValue(baskKey, out int baskula_id))
                            {
                                Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold][/]Baskula ez da aurkitu DatuBasea-n" + baskula);
                                continue;
                            }

                            string produktua = parts[0].Trim();
                            string prodKey = produktua.Trim().ToLowerInvariant();

                            if (!Datubasea.produktuaIdByName.TryGetValue((prodKey, baskula_id), out int produktua_id))
                            {
                                Console.WriteLine($"Produktua ez da aurkitu Datubasea-n: {produktua} (baskula: {baskula})");
                                continue;
                            }

                            string s = parts[1].Trim().ToLowerInvariant();
                            int saltzailea_id = (s == Datubasea.autosalmentaIzena) ? 0 : int.Parse(s);

                            double prezioa = double.Parse(parts[2].Trim(), es);
                            double kopurua = double.Parse(parts[3].Trim(), es);
                            double prezioguztira = double.Parse(parts[4].Trim(), es);

                            Tiketa t = new Tiketa(baskula_id, produktua_id, saltzailea_id, prezioa, kopurua, prezioguztira, data);
                            lt.Add(t);
                        }
                        else
                        {
                            Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold]Ez dago tiketik prozesatzeko[/]" + Path.GetFileName(fitx) + ": " + lerroa);
                        }
                    }
                }

                MugituTxtGuztiak(karpetatiketak);
            }

            return lt.Count == 0;
        }
        public static void ExceleraGorde(string xmlBidea, string jaso)
        {
            string excelBidea = @"\\MSIDEANDONI\CentralTicketBAI\erregistroa.xlsx";
            string orria = "Bidalketak";

            FileInfo info = new FileInfo(xmlBidea);

            XLWorkbook wb;
            IXLWorksheet ws;

            if (File.Exists(excelBidea))
            {
                wb = new XLWorkbook(excelBidea);

                if (wb.Worksheets.Contains(orria))
                    ws = wb.Worksheet(orria);
                else
                {
                    ws = wb.Worksheets.Add(orria);
                    ws.Cell(1, 1).Value = "Data";
                    ws.Cell(1, 2).Value = "Hartzailea";
                    ws.Cell(1, 3).Value = "XML izena";
                    ws.Cell(1, 4).Value = "XML bidea";
                    ws.Cell(1, 5).Value = "Tamaina (KB)";
                }
            }
            else
            {
                wb = new XLWorkbook();
                ws = wb.Worksheets.Add(orria);

                ws.Cell(1, 1).Value = "Data";
                ws.Cell(1, 2).Value = "Hartzailea";
                ws.Cell(1, 3).Value = "XML izena";
                ws.Cell(1, 4).Value = "XML bidea";
                ws.Cell(1, 5).Value = "Tamaina (KB)";
            }

            int azkenErrenkada = ws.LastRowUsed()?.RowNumber() ?? 1;
            int hurrengoa = azkenErrenkada + 1;

            ws.Cell(hurrengoa, 1).Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            ws.Cell(hurrengoa, 2).Value = jaso;
            ws.Cell(hurrengoa, 3).Value = info.Name;
            ws.Cell(hurrengoa, 4).Value = xmlBidea;
            ws.Cell(hurrengoa, 5).Value = Math.Round(info.Length / 1024.0, 2);

            ws.Columns().AdjustToContents();
            wb.SaveAs(excelBidea);
        }
        public static DateTime LortuFitxategiData(string fitxPath)
        {
            DateTime dt = File.GetCreationTime(fitxPath);
            return new DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, 0);
        }
        public static void EnterItxaron()
        {
            Console.WriteLine("\n[ENTER] zapaldu jarraitzeko...");
            while (Console.ReadKey(true).Key != ConsoleKey.Enter) { }
            Console.Clear();
        }
    }
}