﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Spectre.Console;

namespace Erronka
{
    public static class Datubasea
    {
        public static Dictionary<string, int> baskulaIdByName = new Dictionary<string, int>();
        public static Dictionary<(string izena, int baskulaId), int> produktuaIdByName = new Dictionary<(string izena, int baskulaId), int>();
        public static string autosalmentaIzena;
        public static void BaskulakKargatu(string connStr)
        {
            baskulaIdByName.Clear();

            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();

                using (var cmd = new MySqlCommand("SELECT baskula_id, izena FROM baskula;", conn))
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        int id = rd.GetInt32(0);
                        string izena = rd.GetString(1).Trim().ToLowerInvariant();
                        baskulaIdByName[izena] = id;
                    }
                }
            }
        }
        public static void ProduktuakKargatu(string connStr)
        {
            produktuaIdByName.Clear();

            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();

                using (var cmd = new MySqlCommand("SELECT id_produktua, produktuaren_izena, baskula_id FROM produktua;", conn))
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        int id = rd.GetInt32(0);
                        string izena = rd.GetString(1).Trim().ToLowerInvariant();
                        int baskulaId = rd.GetInt32(2);

                        produktuaIdByName[(izena, baskulaId)] = id;
                    }
                }
            }
        }
        public static void AutoSalmentaKargatu(string connStr)
        {
            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();
                using (var cmd = new MySqlCommand("SELECT izena FROM saltzailea WHERE id_saltzailea = 0;", conn))
                {
                    autosalmentaIzena = (cmd.ExecuteScalar()?.ToString() ?? "").Trim().ToLowerInvariant();
                }
            }
        }
        public static void TiketakMysqleraSartu(string connStr, List<Tiketa> lt)
        {
            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();

                string sql = "INSERT INTO tiketa (id_produktua, id_saltzailea, fetxa, kantitatea_kg, prezioa_guztira) " + "VALUES (@idProd, @idSaltz, @fetxa, @kg, @guztira);";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@idProd", MySqlDbType.Int32);
                    cmd.Parameters.Add("@idSaltz", MySqlDbType.Int32);
                    cmd.Parameters.Add("@fetxa", MySqlDbType.DateTime);
                    cmd.Parameters.Add("@kg", MySqlDbType.Decimal);
                    cmd.Parameters.Add("@guztira", MySqlDbType.Decimal);

                    foreach (var t in lt)
                    {
                        cmd.Parameters["@idProd"].Value = t.Produktua;
                        cmd.Parameters["@idSaltz"].Value = t.Langilea;
                        cmd.Parameters["@fetxa"].Value = t.Data;
                        cmd.Parameters["@kg"].Value = (decimal)t.Kopurua;
                        cmd.Parameters["@guztira"].Value = (decimal)t.Prezioguztira;

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }
        public static void TicketakErakutsi()
        {
            List<Saltzailea> SaltzaileLista = Saltzailea.TiketakKargatu();
            if (SaltzaileLista.Count == 0)
            {
                Console.WriteLine("Datu basean ez dago ticketik gordeta");
            }
            else
            {
                int kontadorea = 1;
                int a = SaltzaileLista.Count;
                foreach (Saltzailea t in SaltzaileLista)
                {
                    Console.WriteLine(kontadorea + ". Ticketa");
                    Console.WriteLine("-Ticket ID-a: " + t.Idtiketa);
                    Console.WriteLine("-Produktua: " + t.Produktua);
                    Console.WriteLine("-Saltzailea: " + t.Langilea);
                    Console.WriteLine("-Data: " + t.Data);
                    Console.WriteLine("-Kantitatea: " + t.Kopurua);
                    Console.WriteLine("-Guztira: " + t.Prezioguztira);
                    Console.WriteLine();
                    kontadorea++;
                }
                Console.WriteLine("Saltzaileak:");
                Console.WriteLine("0 = autosalmenta");
                Console.WriteLine("1 = lander");
                Console.WriteLine("2 = ander");
                Console.WriteLine("3 = mateo");
                Console.WriteLine("4 = unai");
                Console.WriteLine("5 = eber");
                Console.WriteLine("6 = igor");
                Console.WriteLine("7 = mario");
                Console.WriteLine();

                try
                {
                    Console.WriteLine("Sartu saltzailea aldatu nahi duzun ticketeko zenbakia");
                    Console.Write("Aukeraketa: ");
                    int aukeraketa = int.Parse(Console.ReadLine());
                    if (aukeraketa > 0 & aukeraketa <= a)
                    {
                        Console.WriteLine("Sartu saltzaile berriaren id-a");
                        int aldaketa = int.Parse(Console.ReadLine());
                        if (aldaketa >= 0 & aldaketa <= 7)
                        {
                            int tiketazenbakia = SaltzaileLista[aukeraketa - 1].Idtiketa;
                            UpdateSaltzailea(tiketazenbakia, aldaketa);
                        }
                        else
                        {
                            Console.WriteLine("sartu duzun zenbakiak ez du loturarik langileekin");
                            Console.WriteLine();
                            Console.WriteLine("Menura itzultzen...");
                            Thread.Sleep(3000);
                            Console.Clear();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ez dago Ticketik zenbaki horrekin");
                        Console.WriteLine();
                        Console.WriteLine("Menura itzultzen...");
                        Thread.Sleep(3000);
                        Console.Clear();
                    }
                }
                catch
                {
                    Console.WriteLine("Ez duzu zenbaki bat sartu");
                    Console.WriteLine();
                }
            }
        }
        public static void UpdateSaltzailea(int tiketaznebakia, int aldaketa)
        {
            using var conn = new MySqlConnection("Server=localhost;Port=3306;Database=supermerkatua;Uid=root;Pwd=root;");
            conn.Open();

            string sql = "UPDATE tiketa SET id_saltzailea=@aldaketa WHERE id_tiketa=@id;";
            using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@aldaketa", aldaketa);
            cmd.Parameters.AddWithValue("@id", tiketaznebakia);

            cmd.ExecuteNonQuery();
        }
    }
}

