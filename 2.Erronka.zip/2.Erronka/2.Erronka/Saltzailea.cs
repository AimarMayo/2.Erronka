﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spectre.Console;

namespace Erronka
{
    public class Saltzailea
    {
        private decimal kopurua, prezioguztira;
        private DateTime data;
        private int produktua, langilea,idtiketa;

        public int Idtiketa { get => idtiketa; set => idtiketa = value; }
        public int Langilea { get => langilea; set => langilea = value; }

        public int Produktua { get => produktua; set => produktua = value; }
        public decimal Kopurua { get => kopurua; set => kopurua = value; }
        public decimal Prezioguztira { get => prezioguztira; set => prezioguztira = value; }
        public DateTime Data { get => data; set => data = value; }
        public Saltzailea() { }
        public Saltzailea(int i, int p, int l, DateTime d, decimal k, decimal pg)
        {
            this.Idtiketa = i;
            this.Produktua = p;
            this.langilea = l;
            this.kopurua = k;
            this.prezioguztira = pg;
            this.data = d;
        }

        public static List<Saltzailea> TiketakKargatu()
        {
            var lista = new List<Saltzailea>();

            using (var conn = new MySqlConnection("Server=localhost;Port=3306;Database=supermerkatua;Uid=root;Pwd=root;"))
            {
                conn.Open();

                string sql = @"SELECT id_tiketa, id_produktua, id_saltzailea, fetxa, kantitatea_kg, prezioa_guztira
                       FROM tiketa
                       ORDER BY id_tiketa;";

                using (var cmd = new MySqlCommand(sql, conn))
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        int idTiketa = rd.GetInt32("id_tiketa");
                        int idProduktua = rd.GetInt32("id_produktua");
                        int idSaltzailea = rd.GetInt32("id_saltzailea");
                        DateTime fetxa = rd.GetDateTime("fetxa");

                        decimal kantitateaKg = Convert.ToDecimal(rd["kantitatea_kg"]);
                        decimal prezioaGuztira = Convert.ToDecimal(rd["prezioa_guztira"]);

                        lista.Add(new Saltzailea(idTiketa, idProduktua, idSaltzailea, fetxa, kantitateaKg, prezioaGuztira));
                    }
                }
            }

            return lista;
        }

        public static void SaltzaileaAldatu(List<Tiketa> lt)
        {
            int a = lt.Count;
            int kontadorea = 1;
            foreach (Tiketa t in lt)
            {
                Console.WriteLine(kontadorea + ". Ticketa");
                Console.WriteLine("-baskula: " + t.Baskula);
                Console.WriteLine("-Produktua: " + t.Produktua);
                Console.WriteLine("-Saltzailea: " + t.Langilea);
                Console.WriteLine("-Prezioa: " + t.Prezioa);
                Console.WriteLine("-Kantitatea: " + t.Kopurua);
                Console.WriteLine("-Guztira: " + t.Prezioguztira);
                Console.WriteLine("-Data: " + t.Data);
                Console.WriteLine();
                kontadorea++;
            }
            Console.WriteLine("Saltzaileak:");
            Console.WriteLine("0 = autosalmenta");
            Console.WriteLine("1 = lander");
            Console.WriteLine("2 = ander");
            Console.WriteLine("3 = mateo");
            Console.WriteLine("4 = unai");
            Console.WriteLine("5 = eber");
            Console.WriteLine("6 = igor");
            Console.WriteLine("7 = mario");
            Console.WriteLine();
            aldatu(a, lt);
        }
        public static void aldatu(int a, List<Tiketa> lt)
        {
            try
            {
                Console.WriteLine("Sartu saltzailea aldatu nahi duzun ticketeko zenbakia");
                Console.Write("Aukeraketa: ");
                int aukeraketa = int.Parse(Console.ReadLine());
                if (aukeraketa > 0 & aukeraketa < a)
                {
                    Console.WriteLine("Sartu saltzaile berriaren id-a");
                    int aldaketa = int.Parse(Console.ReadLine());
                    if (aldaketa >= 0 & aldaketa <= 7)
                    {
                        lt[aukeraketa - 1].Langilea = aldaketa;
                    }
                    else
                    {
                        Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold][/]sartu duzun zenbakiak ez du loturarik langileekin");
                        Console.WriteLine();
                        Console.WriteLine("Menura itzultzen...");
                        Thread.Sleep(3000);
                        Console.Clear();
                    }
                }
                else
                {
                    Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold][/]Ez dago Ticketik zenbaki horrekin");
                    Console.WriteLine();
                    Console.WriteLine("Menura itzultzen...");
                    Thread.Sleep(3000);
                    Console.Clear();
                }
            }
            catch
            {
                Spectre.Console.AnsiConsole.MarkupLine("[red]✗[/] [bold][/]Ez duzu zenbaki bat sartu");
                Console.WriteLine();
                Console.Clear();
            }
        }
    }
}
