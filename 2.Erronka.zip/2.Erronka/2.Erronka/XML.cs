﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Spectre.Console;

namespace Erronka
{
    public class XML
    {
        public static void TiketakXmlraGorde(List<Tiketa> lt)
        {
            string lekua = @"\\MSIDEANDONI\CentralTicketBAI";

            string xmlKarpeta = Path.Combine(lekua, "XML");
            Directory.CreateDirectory(xmlKarpeta);

            string xmlFitx = Path.Combine(xmlKarpeta, $"tiketak_{DateTime.Now:yyyyMMdd_HHmmss}.xml");

            var serializer = new XmlSerializer(typeof(List<Tiketa>), new XmlRootAttribute("Tiketak"));

            using (var fs = new FileStream(xmlFitx, FileMode.Create))
            {
                serializer.Serialize(fs, lt);
            }

            Spectre.Console.AnsiConsole.MarkupLine("[green]✓[/] Tiketak egoki prozesatu dira");
        }
        public static string HartuXmlBidea()
        {
            string karpeta = @"\\MSIDEANDONI\CentralTicketBAI\XML";

            string[] xmlak = Directory.GetFiles(karpeta, "*.xml");

            if (xmlak.Length == 0)
                throw new FileNotFoundException("Ez dago .xml fitxategirik karpeta honetan: " + karpeta);

            return xmlak[0];
        }
        public static bool Balidatu(string xml, string xsd)
        {
            bool ok = true;

            var s = new XmlReaderSettings { ValidationType = ValidationType.Schema };
            s.Schemas.Add(null, xsd);
            s.ValidationEventHandler += (_, e) => { ok = false; Console.WriteLine(e.Message); };

            using var r = XmlReader.Create(xml, s);
            while (r.Read()) { }

            return ok;
        }
        public static void BidaliXml()
        {
            string karpeta = @"\\MSIDEANDONI\CentralTicketBAI\XML";
            string jaso = "ogasunaizarraitz@gmail.com";

            string[] xmlak = Directory.GetFiles(karpeta, "*.xml");

            if (xmlak.Length == 0)
                throw new Exception("Ez dago .xml fitxategirik karpeta honetan: " + karpeta);

            string xmlBidea = xmlak[0];

            Type outlookType = Type.GetTypeFromProgID("Outlook.Application");
            if (outlookType == null)
                throw new Exception("Outlook ez dago instalatuta ordenagailu honetan.");

            dynamic outlookApp = Activator.CreateInstance(outlookType);
            dynamic mail = outlookApp.CreateItem(0);

            mail.To = jaso;
            mail.Subject = "Ticketak XML formatuan";
            mail.Body = "Kaixo, hemen dago XML-a gure 4 baskulek egindako ticketekin";
            mail.Attachments.Add(xmlBidea);

            mail.Send();

            Funtzioak.ExceleraGorde(xmlBidea, jaso);
        }
        public static void MugituXml()
        {
            string rutaOrigen = @"\\MSIDEANDONI\CentralTicketBAI\XML";
            string rutaDestino = @"\\MSIDEANDONI\CentralTicketBAI\BackUp\XML";

            try
            {
                if (Directory.Exists(rutaOrigen))
                {
                    string[] artxiboakXml = Directory.GetFiles(rutaOrigen, "*.xml");

                    foreach (string artxiboRuta in artxiboakXml)
                    {
                        string izena = Path.GetFileName(artxiboRuta);
                        string Mugitu = Path.Combine(rutaDestino, izena);

                        if (!File.Exists(Mugitu))
                        {
                            File.Move(artxiboRuta, Mugitu);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
